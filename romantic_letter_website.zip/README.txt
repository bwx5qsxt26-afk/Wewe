ROMANTIC LETTER WEBSITE

HOW TO USE:
1. Put your song file in this folder and rename it exactly:
   music.mp3

2. Open index.html in any browser.

3. Or upload the files to:
   - Netlify
   - Vercel
   - GitHub Pages

Current song requested:
"Serrure #667" by La Rvfleuze

NOTE:
For copyright reasons, the actual MP3 is not included.
